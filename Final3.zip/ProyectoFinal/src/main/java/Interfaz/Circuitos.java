package Interfaz;

import Contenido.ClaseCircuitos;
import java.util.List;

public interface Circuitos {
    public void registrar(ClaseCircuitos book) throws Exception;
    public void modificar(ClaseCircuitos book) throws Exception;
    public void eliminar(int bookId) throws Exception;
    public List<ClaseCircuitos> listar(String title) throws Exception;
    public ClaseCircuitos getBookById(int bookId) throws Exception;
}
