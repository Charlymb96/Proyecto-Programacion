package Interfaz;

import Contenido.ClaseUsuarios;
import java.util.List;

public interface Usuarios {
    public void registrar(ClaseUsuarios user) throws Exception;
    public void modificar(ClaseUsuarios user) throws Exception;
    public void sancionar(ClaseUsuarios user) throws Exception;
    public void eliminar(int userId) throws Exception;
    public List<ClaseUsuarios> listar(String name) throws Exception;
    public ClaseUsuarios getUserById(int userId) throws Exception;
}