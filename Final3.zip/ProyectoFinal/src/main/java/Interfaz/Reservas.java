package Interfaz;

import Contenido.ClaseCircuitos;
import Contenido.ClaseReservas;
import Contenido.ClaseUsuarios;
import java.util.List;

public interface Reservas {
    public void registrar(ClaseReservas lending) throws Exception;
    public void modificar(ClaseReservas lending) throws Exception;
    public ClaseReservas getLending(ClaseUsuarios user, ClaseCircuitos book) throws Exception;
    // public void eliminar(Lendings user) throws Exception;
    public List<ClaseReservas> listar() throws Exception;
}
