package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {

    protected Connection conexion;
    private final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    private final String DB_URL = "jdbc:mysql://localhost:3307/Parrita?serverTimezone=UTC";
    private final String USER = "root";
    private final String PASS = "admin";

    public void Conectar() throws ClassNotFoundException {
        try {
            Class.forName(JDBC_DRIVER); // cargar driver antes
            conexion = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("✅ Conexión exitosa");
        } catch (SQLException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("❌ Error al conectar: " + ex.getMessage());
        }
    }

    public void Cerrar() throws SQLException {
        if (conexion != null && !conexion.isClosed()) {
            conexion.close();
        }
    }
}